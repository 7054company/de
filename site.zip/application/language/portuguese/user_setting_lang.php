<?php 
$lang["proxy"] = "procuração";
$lang["proxy port"] = "porta proxy";
$lang["proxy username"] = "nome de usuário de proxy";
$lang["proxy password"] = "senha de proxy";
$lang["admin permission"] = "permissão de administrador";