<?php

$lang['package settings'] = 'paramètres du paquet';
$lang['package name'] = 'nom du package';
$lang['price'] = 'prix';
$lang['modules'] = 'modules';
$lang['validity'] = 'validité';
$lang['days'] = 'journées';
// $lang['Keyword'] = 'Mot-clé';
$lang['Website'] = 'site Web';
$lang['Country'] = 'pays';
// $lang['Language'] = 'langue';
$lang['Keyword Position Tracking'] = 'Analyse des mots clés Position';
$lang['Keyword Tracking Settings'] = 'Paramètres de suivi de mots-clés';
$lang['Keyword Position Report'] = 'Mot-clé Rapport de position';
$lang['Search Panel'] = 'Panneau de Recherche';
$lang['default package'] = 'Default package';
$lang['keyword list'] = 'Keyword liste';
$lang['expired date'] = "date d'expiration";
$lang['select keyword'] = 'Mot-clé';
$lang['select language'] = 'langue';

$lang["Today's Country Wise New Visitor Report - Top Five"] = "Pays Sage aujourd'hui un nouveau rapport des visiteurs - Top 5";
$lang["Today's New Vs Returning Users Report"] = "New Vs Utilisateurs de retour d'aujourd'hui Rapport";
$lang['to know details'] = 'Pour connaître les détails';
$lang['read documentation'] = 'Lire la documentation';
$lang['mobile ready check'] = 'Mobile Check Ready';

$lang['0 means unlimited'] = '0 signifie illimité';
$lang['All Modules'] = 'Tous les modules';
$lang['Analysis Limit'] = "Limite d'analyse";
$lang['Bulk Limit'] = 'Limite Bulk';
$lang['Month'] = 'Mois';
$lang['Analysis'] = 'Une analyse';

$lang['sorry, your monthly limit is exceeded for this module.'] = 'désolé, votre limite mensuelle est dépassée pour ce module.';
$lang['sorry, your limit is exceeded for this module.'] = 'désolé, votre limite est dépassée pour ce module.';
$lang['sorry, your bulk limit is exceeded for this module.'] = 'désolé, votre limite est dépassée en vrac pour ce module.';
$lang['click here to see usage log'] = "cliquez ici pour voir journal d'utilisation";
$lang['usage log'] = "journal d'utilisation";


$lang['Analysis Done'] = 'Analyse Fait';
$lang['unlimited'] = 'illimité';

$lang['payment option'] = 'Modalité de paiement';
$lang['choose package'] = 'choisissez package';



