<?php 
$lang["proxy"] = "Procuration";
$lang["proxy port"] = "port proxy";
$lang["proxy username"] = "nom d'utilisateur proxy";
$lang["proxy password"] = "mot de passe proxy";
$lang["admin permission"] = "permission admin";