<?php 
$lang["proxy"] = "Πληρεξούσιο";
$lang["proxy port"] = "Θύρα proxy";
$lang["proxy username"] = "μεσολάβησης Όνομα Χρήστη";
$lang["proxy password"] = "μεσολάβησης Κωδικός";
$lang["admin permission"] = "άδεια διαχειριστή";