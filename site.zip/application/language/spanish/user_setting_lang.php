<?php 
$lang["proxy"] = "apoderado";
$lang["proxy port"] = "Puerto proxy";
$lang["proxy username"] = "nombre de usuario de proxy";
$lang["proxy password"] = "contraseña del proxy";
$lang["admin permission"] = "el permiso de administrador";