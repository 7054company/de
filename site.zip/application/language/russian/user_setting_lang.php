<?php 
$lang["proxy"] = "доверенное лицо";
$lang["proxy port"] = "порт прокси";
$lang["proxy username"] = "Имя пользователя прокси";
$lang["proxy password"] = "прокси-пароль";
$lang["admin permission"] = "разрешение администратора";