<?php 
$lang["proxy"] = "প্রক্সি";
$lang["proxy port"] = "casfdfasdf";
$lang["proxy username"] = "casfdfasdf";
$lang["proxy password"] = "casfdfasdf";
$lang["admin permission"] = "casfdfasdf";